default[:dr_failover] = false
default[:dr_environment_name] = "replication_monitoring_test"